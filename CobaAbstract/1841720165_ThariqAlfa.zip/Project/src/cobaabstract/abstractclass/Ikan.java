package cobaabstract.abstractclass;

/**
 *
 * @author Windows
 */
public class Ikan extends Hewan {

    @Override
    public void bergerak() {
       System.out.println("Bergerak dengan sirip, \"wush..wush..\""); 
    } 
}