package cobaabstract.abstractclass;

/**
 *
 * @author Windows
 */
public class Kucing extends Hewan{

    @Override
    public void bergerak() {
        System.out.println("Bergerak dengan kaki, \"Tap..tap..\"");
    }   
}