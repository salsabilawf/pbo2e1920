package cobainterface;

/**
 *
 * @author Windows
 */
public class Program 
{
    public static void main(String[] args) 
    {
    Rektor pakRektor = new Rektor();

    //Mahasiswa mahasiswaBiasa = new Mahasiswa("Charlie");
    Sarjana sarjanaCumlaude = new Sarjana("Dini");
    PascaSarjana masterCumlaude = new PascaSarjana("masterCumlaude");

   // pakRektor.beriSertifikatCumlaude(mahasiswaBiasa);
   //pakRektor.beriSertifikatCumlaude(sarjanaCumlaude);
   //pakRektor.beriSertifikatCumlaude(masterCumlaude);
    
   pakRektor.beriSertifikatMawapres(sarjanaCumlaude);
   pakRektor.beriSertifikatMawapres(masterCumlaude);
    }
       
}