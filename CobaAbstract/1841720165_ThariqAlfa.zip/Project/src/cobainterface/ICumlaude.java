package cobainterface;

/**
 *
 * @author Windows
 */
public interface ICumlaude 
{
    public abstract void lulus();
    public abstract void meraihIPKTinggi();
}
