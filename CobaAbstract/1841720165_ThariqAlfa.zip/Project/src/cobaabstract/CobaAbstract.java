package cobaabstract;

/**
 *
 * @author Windows
 */
public class CobaAbstract {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
